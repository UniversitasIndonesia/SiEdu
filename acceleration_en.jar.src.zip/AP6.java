/*     */ import java.awt.BasicStroke;
/*     */ import java.awt.Color;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.io.FileReader;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.io.Reader;
/*     */ import java.util.Properties;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JTextField;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class AP6
/*     */   extends JPanel
/*     */   implements ActionListener, Runnable
/*     */ {
/*     */   protected static final double DEG = 0.017453292519943295D;
/*  27 */   protected final BasicStroke THIN = new BasicStroke(1.0F);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected P6 prog;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected A6 applet;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected boolean correct;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String title;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Properties prop;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String language;
/*     */   
/*     */ 
/*     */ 
/*     */   protected Thread thr;
/*     */   
/*     */ 
/*     */ 
/*  65 */   protected String ampere = "A"; protected String milliampere = "mA"; protected String microampere = "µA";
/*     */   
/*     */ 
/*     */ 
/*  69 */   protected String electronvolt = "eV";
/*     */   
/*     */ 
/*     */ 
/*  73 */   protected String farad = "F"; protected String millifarad = "mF"; protected String microfarad = "µF";
/*     */   
/*     */ 
/*     */ 
/*  77 */   protected String degree = "°";
/*     */   
/*     */ 
/*     */ 
/*  81 */   protected String henry = "H";
/*     */   
/*     */ 
/*     */ 
/*  85 */   protected String hertz = "Hz"; protected String terahertz = "THz";
/*     */   
/*     */ 
/*     */ 
/*  89 */   protected String joule = "J";
/*     */   
/*     */ 
/*     */ 
/*  93 */   protected String kelvin = "K";
/*     */   
/*     */ 
/*     */ 
/*  97 */   protected String kilogram = "kg"; protected String gram = "g";
/*     */   
/*     */ 
/*     */ 
/* 101 */   protected String kilogramPerMeter3 = "kg/m³"; protected String gramPerCentimeter3 = "g/cm³";
/*     */   
/*     */ 
/*     */ 
/* 105 */   protected String meter = "m"; protected String centimeter = "cm"; protected String nanometer = "nm";
/*     */   
/*     */ 
/*     */ 
/* 109 */   protected String meter2 = "m²"; protected String centimeter2 = "cm²";
/*     */   
/*     */ 
/*     */ 
/* 113 */   protected String meter3 = "m³"; protected String decimeter3 = "dm³"; protected String centimeter3 = "cm³";
/*     */   
/*     */ 
/*     */ 
/* 117 */   protected String meterPerSecond = "m/s";
/*     */   
/*     */ 
/*     */ 
/* 121 */   protected String meterPerSecond2 = "m/s²";
/*     */   
/*     */ 
/*     */ 
/* 125 */   protected String newton = "N";
/*     */   
/*     */ 
/*     */ 
/* 129 */   protected String newtonPerMeter = "N/m";
/*     */   
/*     */ 
/*     */ 
/* 133 */   protected String ohm = "Ω";
/*     */   
/*     */ 
/*     */ 
/* 137 */   protected String pascal = "Pa"; protected String hectopascal = "hPa"; protected String kilopascal = "kPa";
/*     */   
/*     */ 
/*     */ 
/* 141 */   protected String second = "s";
/*     */   
/*     */ 
/*     */ 
/* 145 */   protected String perSecond = "1/s";
/*     */   
/*     */ 
/*     */ 
/* 149 */   protected String volt = "V";
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public AP6()
/*     */   {
/* 158 */     this.correct = false;
/*     */     
/* 160 */     setLayout(null);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract void initAttributes();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract void initColors();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract void initText();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract void initCanvas();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected abstract void initPanel();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setApplet(A6 a)
/*     */   {
/* 196 */     this.applet = a;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setProg(P6 p)
/*     */   {
/* 204 */     this.prog = p;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Properties newProperties(String fn)
/*     */   {
/*     */     try
/*     */     {
/* 214 */       Properties prop = new Properties();
/* 215 */       Reader reader = new FileReader(fn);
/* 216 */       prop.load(reader);
/* 217 */       reader.close();
/* 218 */       return prop;
/*     */     }
/*     */     catch (IOException ioe) {
/* 221 */       System.out.println(ioe); }
/* 222 */     return null;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String[] searchLanguage(String[][] text, String lang)
/*     */   {
/* 231 */     String[] t = text[0];
/*     */     
/* 233 */     for (int i = 0; i < text.length; i++) {
/* 234 */       t = text[i];
/* 235 */       if (lang.equals(t[0])) break;
/*     */     }
/* 237 */     if (i == text.length) t = text[0];
/* 238 */     this.language = t[0];
/* 239 */     return t;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getDecimalSeparator(String lang)
/*     */   {
/* 248 */     if (lang.equals("en")) return ".";
/* 249 */     return ",";
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String getText(String def, String key)
/*     */   {
/* 260 */     if (this.applet != null) {
/* 261 */       String s = this.applet.getParameter(key);
/* 262 */       if ((s != null) && (!s.equals(""))) return s;
/* 263 */       return def;
/*     */     }
/* 265 */     String text = def;
/* 266 */     if (this.prop != null) {
/* 267 */       String s = this.prop.getProperty(key, text);
/* 268 */       if (!s.equals("")) text = s;
/*     */     }
/* 270 */     return text;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Color color(String hex)
/*     */   {
/* 279 */     int r = Integer.parseInt(hex.substring(0, 2), 16);
/* 280 */     int g = Integer.parseInt(hex.substring(2, 4), 16);
/* 281 */     int b = Integer.parseInt(hex.substring(4), 16);
/* 282 */     return new Color(r, g, b);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Color getColor(Color def, String key)
/*     */   {
/*     */     try
/*     */     {
/* 294 */       if (this.applet != null) {
/* 295 */         return color(this.applet.getParameter(key));
/*     */       }
/* 297 */       return color(this.prop.getProperty(key));
/*     */     } catch (Exception exc) {}
/* 299 */     return def;
/*     */   }
/*     */   
/*     */ 
/*     */   protected void startThread(boolean animation)
/*     */   {
/* 305 */     if (!animation) return;
/* 306 */     this.thr = new Thread(this);this.thr.start();
/*     */   }
/*     */   
/*     */ 
/*     */   private void setUnits()
/*     */   {
/* 312 */     if (this.language.equals("ru")) {
/* 313 */       this.meter = "м";
/* 314 */       this.second = "с";
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void initAP(boolean program, String propFile, boolean animation)
/*     */   {
/* 325 */     if (program) this.prop = newProperties(propFile);
/* 326 */     initAttributes();
/* 327 */     initColors();
/* 328 */     initText();
/* 329 */     if (program) this.prog.setTitle(this.title);
/* 330 */     setUnits();
/* 331 */     initCanvas();
/* 332 */     initPanel();
/* 333 */     startThread(animation);
/*     */   }
/*     */   
/*     */ 
/*     */   protected void end()
/*     */   {
/* 339 */     this.thr = null;removeAll();
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String toString(double a, int n)
/*     */   {
/* 351 */     if (n < 0) return "";
/* 352 */     String sign = a >= 0.0D ? "" : "−";
/* 353 */     a = Math.abs(a);
/* 354 */     long zp = 1L;
/* 355 */     for (int i = 0; i < n; i++) zp *= 10L;
/* 356 */     String s = "" + Math.round(a * zp);
/* 357 */     for (int pos = s.length() - n; 
/* 358 */         pos <= 0; pos++) s = "0" + s;
/* 359 */     String s1 = sign + s.substring(0, pos);
/* 360 */     String sep = getDecimalSeparator(this.language);
/* 361 */     if (n == 0) return s1;
/* 362 */     return s1 + sep + s.substring(pos);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected String toString2(double a, int n, double eps)
/*     */   {
/* 376 */     String sign = a >= 0.0D ? "" : "−";
/* 377 */     double b = Math.abs(a);
/* 378 */     if (b < eps) return "0";
/* 379 */     int z = (int)Math.floor(Math.log(b) / Math.log(10.0D));
/* 380 */     if (z < n) { return sign + toString(b, n - 1 - z);
/*     */     }
/* 382 */     double zp = 1.0D;
/* 383 */     for (int i = 0; i < z; i++) zp *= 10.0D;
/* 384 */     return toString2(a / zp, 3, 1.0E-10D) + "*10^" + z;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected double toDouble(String s)
/*     */   {
/* 394 */     s = s.replace(',', '.');
/* 395 */     s = s.replace('−', '-');
/* 396 */     try { return Double.parseDouble(s); } catch (NumberFormatException e) {}
/* 397 */     return 0.0D;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected double inputTF(JTextField tf, double min, double max, int n)
/*     */   {
/* 411 */     double value = toDouble(tf.getText());
/* 412 */     if (value < min) value = min; if (value > max) value = max;
/* 413 */     tf.setText(toString(value, n));
/* 414 */     return this.correct ? value : 0.0D;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected double inputTF2(JTextField tf, double min, double max, int n, double eps)
/*     */   {
/* 429 */     double value = toDouble(tf.getText());
/* 430 */     if (value < min) value = min; if (value > max) value = max;
/* 431 */     tf.setText(toString2(value, n, eps));
/* 432 */     return this.correct ? value : 0.0D;
/*     */   }
/*     */   
/*     */ 
/*     */   protected double floorP10(double a)
/*     */   {
/* 438 */     int n = (int)Math.floor(Math.log(a) / Math.log(10.0D));
/* 439 */     double p = 1.0D;
/* 440 */     for (int i = 0; i < Math.abs(n); i++) p *= 10.0D;
/* 441 */     return n >= 0 ? p : 1.0D / p;
/*     */   }
/*     */   
/*     */ 
/*     */   protected String copyright(int year)
/*     */   {
/* 447 */     this.correct = true;
/* 448 */     return "©  W. Fendt " + year;
/*     */   }
/*     */ }


/* Location:              C:\Users\User\Downloads\acceleration_en.jar!\AP6.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */