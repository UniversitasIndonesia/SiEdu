/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ import java.awt.GridBagConstraints;
/*     */ import java.awt.GridBagLayout;
/*     */ import java.awt.Insets;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JTextField;
/*     */ 
/*     */ 
/*     */ public class Panel6
/*     */   extends JPanel
/*     */ {
/*  17 */   private final char[] numbers = { '©', ' ', ' ', 'W', '.', ' ', 'F', 'e', 'n', 'd', 't', ' ' };
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private AP6 frame;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private Font fH;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int cols;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int rows;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private int[] gaps;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Panel6(AP6 a, Color c, int sp, int[] g)
/*     */   {
/*  58 */     this.frame = a;
/*  59 */     setBackground(c);
/*  60 */     this.cols = sp;this.rows = 0;
/*  61 */     this.gaps = g;
/*  62 */     setLayout(new GridBagLayout());
/*  63 */     this.fH = new Font("SansSerif", 1, 12);
/*  64 */     setBorder(BorderFactory.createEtchedBorder());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   private String constructString()
/*     */   {
/*  72 */     this.frame.correct = true;
/*  73 */     String s = "";
/*  74 */     for (int i = 0; i < this.numbers.length; i++) s = s + this.numbers[i];
/*  75 */     return s;
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private void add(JComponent comp, Color bg, Color fg, Font f, int x, int w, int weight, int top, int left, int bottom, int right)
/*     */   {
/*  91 */     add(comp);
/*  92 */     if (x == 0) this.rows += 1;
/*  93 */     GridBagConstraints c = new GridBagConstraints();
/*  94 */     c.gridx = x;c.gridy = (this.rows - 1);
/*  95 */     c.gridwidth = w;c.gridheight = 1;
/*  96 */     c.fill = 2;
/*  97 */     c.anchor = 10;
/*  98 */     c.weightx = weight;c.weighty = 1.0D;
/*  99 */     c.insets = new Insets(top, left, bottom, right);
/* 100 */     ((GridBagLayout)getLayout()).setConstraints(comp, c);
/* 101 */     comp.setFont(f);
/* 102 */     comp.setBackground(bg);
/* 103 */     comp.setForeground(fg);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void add(JComponent comp, Color bg, int x, int w, int left, int right)
/*     */   {
/* 116 */     add(comp);
/* 117 */     if (x == 0) this.rows += 1;
/* 118 */     GridBagConstraints c = new GridBagConstraints();
/* 119 */     c.gridx = x;c.gridy = (this.rows - 1);
/* 120 */     c.gridwidth = w;c.gridheight = 1;
/* 121 */     c.fill = 2;
/* 122 */     c.anchor = 10;
/* 123 */     c.weightx = 1.0D;c.weighty = 1.0D;
/* 124 */     c.insets = new Insets(top(), left, bottom(), right);
/* 125 */     ((GridBagLayout)getLayout()).setConstraints(comp, c);
/* 126 */     comp.setFont(this.fH);
/* 127 */     comp.setBackground(bg);
/* 128 */     comp.setForeground(Color.black);
/*     */   }
/*     */   
/*     */   private int top()
/*     */   {
/*     */     try {
/* 134 */       return this.gaps[this.rows]; } catch (Exception exc) {}
/* 135 */     return 0;
/*     */   }
/*     */   
/*     */   private int bottom()
/*     */   {
/*     */     try {
/* 141 */       return this.rows == this.gaps.length - 2 ? this.gaps[(this.rows + 1)] : 0; } catch (Exception exc) {}
/* 142 */     return 0;
/*     */   }
/*     */   
/*     */ 
/*     */   public void add(JComponent comp, Color bg, Color fg)
/*     */   {
/* 148 */     add(comp, bg, fg, this.fH, 0, this.cols, 1, top(), 10, bottom(), 10);
/*     */   }
/*     */   
/*     */ 
/*     */   public void add(String s, Color fg)
/*     */   {
/* 154 */     JLabel lb = new JLabel(s);
/* 155 */     add(lb, getBackground(), fg);
/*     */   }
/*     */   
/*     */ 
/*     */   public void add(String s)
/*     */   {
/* 161 */     add(s, Color.black);
/*     */   }
/*     */   
/*     */ 
/*     */   public JButton newButton(String s, Color bg, Color fg)
/*     */   {
/* 167 */     JButton bu = new JButton(s);
/* 168 */     add(bu, bg, fg, this.fH, 0, this.cols, 1, top(), 10, bottom(), 10);
/* 169 */     bu.addActionListener(this.frame);
/* 170 */     return bu;
/*     */   }
/*     */   
/*     */ 
/*     */   public JButton newButton(String s, Color bg)
/*     */   {
/* 176 */     return newButton(s, bg, Color.black);
/*     */   }
/*     */   
/*     */ 
/*     */   public JTextField newInputField(String s, String u, Color bg, Color fg, int weight)
/*     */   {
/* 182 */     int top = top();int bottom = bottom();
/* 183 */     JLabel lbLeft = new JLabel(s);
/* 184 */     add(lbLeft, bg, fg, this.fH, 0, 1, 1, top, 10, bottom, 0);
/* 185 */     JTextField tf = new JTextField();
/* 186 */     add(tf, Color.white, fg, this.fH, 1, 1, weight, top, 0, bottom, 0);
/* 187 */     JLabel lbRight = new JLabel(u);
/* 188 */     add(lbRight, bg, fg, this.fH, 2, 1, 1, top, 5, bottom, 10);
/* 189 */     tf.addActionListener(this.frame);
/* 190 */     return tf;
/*     */   }
/*     */   
/*     */ 
/*     */   public JLabel newOutputField(String s, String u, Color bg, Color fg, int weight)
/*     */   {
/* 196 */     int top = top();int bottom = bottom();
/* 197 */     JLabel lbLeft = new JLabel(s);
/* 198 */     add(lbLeft, bg, fg, this.fH, 0, 1, 1, top, 10, bottom, 0);
/* 199 */     JLabel lb = new JLabel();
/* 200 */     add(lb, bg, fg, this.fH, 1, 1, weight, top, 0, bottom, 0);
/* 201 */     JLabel lbRight = new JLabel(u);
/* 202 */     add(lbRight, bg, fg, this.fH, 2, 1, 1, top, 5, bottom, 10);
/* 203 */     return lb;
/*     */   }
/*     */   
/*     */ 
/*     */   public void add(int year)
/*     */   {
/* 209 */     add(constructString() + year);
/*     */   }
/*     */ }


/* Location:              C:\Users\User\Downloads\acceleration_en.jar!\Panel6.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */