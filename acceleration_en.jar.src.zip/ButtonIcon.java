/*    */ import java.awt.Color;
/*    */ import java.awt.Component;
/*    */ import java.awt.Graphics;
/*    */ import java.awt.Polygon;
/*    */ import javax.swing.ImageIcon;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ButtonIcon
/*    */   extends ImageIcon
/*    */ {
/*    */   private static final int WIDTH = 30;
/*    */   private static final int HEIGHT = 20;
/*    */   protected static final int RESET = 0;
/*    */   protected static final int PLAY = 1;
/*    */   protected static final int PAUSE = 2;
/* 40 */   private static final Polygon LEFT = new Polygon(new int[] { 10, 0, 10 }, new int[] { 5, 0, -5 }, 3);
/*    */   
/*    */ 
/*    */ 
/* 44 */   private static final Polygon RIGHT = new Polygon(new int[] { 5, -5, -5 }, new int[] { 0, -5, 5 }, 3);
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   private int type;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public ButtonIcon(int t)
/*    */   {
/* 63 */     this.type = t;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void paintIcon(Component c, Graphics g, int x, int y)
/*    */   {
/* 79 */     g.setColor(c.getBackground());
/* 80 */     g.fillRect(x - 15, y - 10, 30, 20);
/* 81 */     g.setColor(Color.black);
/*    */     int dx;
/* 83 */     int dy; switch (this.type) {
/*    */     case 0: 
/* 85 */       dx = x - LEFT.xpoints[1];
/* 86 */       dy = y - LEFT.ypoints[1];
/* 87 */       LEFT.translate(dx, dy);
/* 88 */       g.fillPolygon(LEFT);
/* 89 */       LEFT.translate(-10, 0);
/* 90 */       g.fillPolygon(LEFT);
/* 91 */       break;
/*    */     case 1: 
/* 93 */       dx = x + 5 - RIGHT.xpoints[0];
/* 94 */       dy = y - RIGHT.ypoints[0];
/* 95 */       RIGHT.translate(dx, dy);
/* 96 */       g.fillPolygon(RIGHT);
/* 97 */       break;
/*    */     case 2: 
/* 99 */       g.fillRect(x - 5, y - 3, 10, 6);
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\User\Downloads\acceleration_en.jar!\ButtonIcon.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */