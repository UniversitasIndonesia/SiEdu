/*    */ import java.awt.Color;
/*    */ import javax.swing.JButton;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ResetButton
/*    */   extends JButton
/*    */ {
/*    */   public ResetButton(String s)
/*    */   {
/* 23 */     setBackground(Color.cyan);
/* 24 */     setIcon(new ButtonIcon(0));
/* 25 */     setText(s);
/* 26 */     setIconTextGap(50);
/* 27 */     setFocusPainted(false);
/*    */   }
/*    */ }


/* Location:              C:\Users\User\Downloads\acceleration_en.jar!\ResetButton.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */