/*     */ import java.awt.Color;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import javax.swing.JRadioButton;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class AccelerationAP$CanvasAP
/*     */   extends Canvas6
/*     */ {
/*     */   AccelerationAP$CanvasAP(AccelerationAP paramAccelerationAP, AP6 ap)
/*     */   {
/* 347 */     super(ap, paramAccelerationAP.bgCanvas);
/* 348 */     paramAccelerationAP.fmH = getFontMetrics(this.fH);
/*     */   }
/*     */   
/*     */ 
/*     */   void horArrow(Graphics2D g, double x0, double y0, double w)
/*     */   {
/* 354 */     arrow(g, 3.0D, x0, y0, x0 + w, y0);
/*     */   }
/*     */   
/*     */ 
/*     */   void street(Graphics2D g)
/*     */   {
/* 360 */     g.setColor(Color.black);
/* 361 */     line(g, 1.0D, 60.0D, 538.0D, 60.0D);
/* 362 */     int xx = 500;int yy = 75;
/* 363 */     arrow(g, 40.0D, yy, xx, yy);
/* 364 */     alignText(g, "x", this.fH, 1, xx, yy + 15);
/* 365 */     alignText(g, this.this$0.text12, this.fH, 1, xx, yy + 25);
/* 366 */     int pix5 = 40;
/* 367 */     for (int i = 0; i <= 10; i++) {
/* 368 */       xx = 50 + i * pix5;
/* 369 */       line(g, xx, yy - 2, xx, yy + 2);
/* 370 */       alignText(g, "" + i * 5, this.fH, 1, xx, yy + 15);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   void car(Graphics2D g)
/*     */   {
/* 377 */     this.this$0.x = (this.this$0.a * this.this$0.t * this.this$0.t / 2.0D + this.this$0.v0 * this.this$0.t + this.this$0.x0);
/* 378 */     this.this$0.v = (this.this$0.a * this.this$0.t + this.this$0.v0);
/* 379 */     double xNeu = 50.0D + this.this$0.x * 8.0D;
/* 380 */     double dx = xNeu - this.this$0.xx;
/* 381 */     this.this$0.xx = xNeu;
/* 382 */     this.this$0.translate(dx);
/* 383 */     polygon(g, this.this$0.xCar, this.this$0.yCar, this.this$0.colorCar1, true);
/* 384 */     polygon(g, this.this$0.xWindow, this.this$0.yWindow, this.this$0.colorCar2, true);
/* 385 */     double yy = 57.0D;
/* 386 */     line(g, xNeu - 18.0D, yy, xNeu - 18.0D, 48.0D);
/* 387 */     circle(g, xNeu - 23.0D, yy, 3.0D, Color.black, true);
/* 388 */     circle(g, xNeu - 7.0D, yy, 3.0D, Color.black, true);
/* 389 */     circle(g, xNeu - 16.0D, 50.0D, 1.0D, Color.black, true);
/* 390 */     yy = 54.0D;
/* 391 */     if (this.this$0.rbV.isSelected()) {
/* 392 */       g.setColor(this.this$0.colorVelocity);
/* 393 */       double vv = this.this$0.v * 3.0D;
/* 394 */       if (this.this$0.v > 0.0D) horArrow(g, xNeu, yy, vv);
/* 395 */       if (this.this$0.v < 0.0D) horArrow(g, xNeu - 30.0D, yy, vv);
/*     */     }
/*     */     else {
/* 398 */       g.setColor(this.this$0.colorAcceleration);
/* 399 */       double vv = this.this$0.a * 30.0D;
/* 400 */       if (this.this$0.a > 0.0D) horArrow(g, xNeu, yy, vv);
/* 401 */       if (this.this$0.a < 0.0D) { horArrow(g, xNeu - 30.0D, yy, vv);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */   void lBarrier(Graphics2D g, double x, Color c)
/*     */   {
/* 410 */     rectangle(g, 50.0D + x * 8.0D - 2.0D, 40.0D, 5.0D, 20.0D, c, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   void clock(Graphics2D g, int x, int y, double t, Color c)
/*     */   {
/* 419 */     rectangle(g, x - 60, y - 15, 120.0D, 30.0D, c, true);
/* 420 */     rectangle(g, x - 50, y - 10, 100.0D, 20.0D, Color.black, true);
/* 421 */     g.setColor(Color.red);g.setFont(this.this$0.fC);
/* 422 */     int n = (int)(t / 100.0D);t -= 100 * n;
/* 423 */     String s = this.this$0.valToString("", t, 3, " s");
/* 424 */     int w = this.this$0.fmC.stringWidth(s);
/* 425 */     setAntiAliasing(g, false);
/* 426 */     g.drawString(s, x - w / 2, y + 5);
/* 427 */     setAntiAliasing(g, true);
/* 428 */     g.setFont(this.fH);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */   void cosy(Graphics2D g, int x, int y, int yMinus, int yPlus)
/*     */   {
/* 436 */     g.setColor(Color.black);
/* 437 */     arrow(g, x - 10, y, x + 110, y);
/* 438 */     arrow(g, x, y - yMinus, x, y - yPlus);
/* 439 */     for (int i = 1; i <= 5; i++) {
/* 440 */       int xx = x + i * 2 * 8;
/* 441 */       line(g, xx, y - 3, xx, y + 3);
/* 442 */       alignText(g, "" + 2 * i, this.fH, 1, xx, y + 15);
/*     */     }
/* 444 */     alignText(g, "t", this.fH, 1, x + 105, y + 15);
/* 445 */     alignText(g, this.this$0.text11, this.fH, 1, x + 105, y + 25);
/*     */   }
/*     */   
/*     */ 
/*     */   void diagramTX(Graphics2D g)
/*     */   {
/* 451 */     int xU = 50;int yU = 330;
/* 452 */     double pixT = 8.0D;
/* 453 */     cosy(g, 50, 330, -10, 150);
/* 454 */     for (int i = 1; i <= 6; i++) {
/* 455 */       int yy = 330 - i * 10 * 2;
/* 456 */       line(g, 47.0D, yy, 53.0D, yy);
/* 457 */       alignText(g, "" + 10 * i, this.fH, 2, 40, yy + 4);
/*     */     }
/* 459 */     g.setColor(this.this$0.colorPosition);
/* 460 */     alignText(g, "x", this.fH, 1, 30, 185);
/* 461 */     alignText(g, this.this$0.text12, this.fH, 1, 30, 195);
/* 462 */     alignText(g, this.this$0.valToString("x = ", this.this$0.x, 2, " " + this.this$0.meter), this.fH, 1, 110, 380);
/* 463 */     double xx = 50.0D + this.this$0.t * 8.0D;double yy = 330.0D - this.this$0.x * 2.0D;
/* 464 */     if ((xx <= 150.0D) && (yy <= 330.0D) && (yy >= 190.0D))
/* 465 */       circle(g, xx, yy, 2.0D, this.this$0.colorPosition, true);
/* 466 */     g.setColor(this.this$0.colorPosition);
/* 467 */     int x0 = 50;int x1 = x0 + 1;
/* 468 */     double y0 = 330.0D - this.this$0.getX0() * 2.0D;
/* 469 */     for (; (x1 <= xx) && (x1 <= 150); 
/*     */         
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 475 */         x1++)
/*     */     {
/* 470 */       double tt = (x1 - 50) / pixT;
/* 471 */       this.this$0.x = (this.this$0.a * tt * tt / 2.0D + this.this$0.v0 * tt + this.this$0.getX0());
/* 472 */       double y1 = 330.0D - this.this$0.x * 2.0D;
/* 473 */       if ((y0 <= 360.0D) && (y0 >= 190.0D) && (y1 <= 360.0D) && (y1 >= 190.0D))
/* 474 */         line(g, x0, y0, x1, y1);
/* 475 */       x0 = x1;y0 = y1;
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   void diagramTV(Graphics2D g)
/*     */   {
/* 482 */     int xU = 220;int yU = 270;
/* 483 */     cosy(g, 220, 270, -70, 90);
/* 484 */     for (int i = -4; i <= 4; i++)
/* 485 */       if (i != 0) {
/* 486 */         int yy = 270 - i * 5 * 3;
/* 487 */         line(g, 217.0D, yy, 223.0D, yy);
/* 488 */         alignText(g, "" + 5 * i, this.fH, 2, 210, yy + 4);
/*     */       }
/* 490 */     g.setColor(this.this$0.colorVelocity);
/* 491 */     alignText(g, "v", this.fH, 1, 195, 185);
/* 492 */     alignText(g, this.this$0.text13, this.fH, 1, 195, 195);
/* 493 */     alignText(g, this.this$0.valToString("v = ", this.this$0.v, 2, " " + this.this$0.meterPerSecond), this.fH, 1, 280, 380);
/* 494 */     double xx = 220.0D + this.this$0.t * 8.0D;double yy = 270.0D - this.this$0.v * 3.0D;
/* 495 */     double yy0 = 270.0D - this.this$0.v0 * 3.0D;
/* 496 */     if (xx <= 320.0D) {
/* 497 */       circle(g, xx, yy, 2.0D, this.this$0.colorVelocity, true);
/* 498 */       g.setColor(this.this$0.colorVelocity);
/* 499 */       line(g, 220.0D, yy0, xx, yy);
/*     */     }
/*     */     else {
/* 502 */       yy = 270.0D - (this.this$0.a * 100.0D / 8.0D + this.this$0.v0) * 3.0D;
/* 503 */       line(g, 220.0D, yy0, 320.0D, yy);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */   void diagramTA(Graphics2D g)
/*     */   {
/* 510 */     int xU = 390;int yU = 270;
/* 511 */     cosy(g, 390, 270, -70, 90);
/* 512 */     for (int i = -2; i <= 2; i++)
/* 513 */       if (i != 0) {
/* 514 */         int yy = 270 - i * 30;
/* 515 */         line(g, 387.0D, yy, 393.0D, yy);
/* 516 */         alignText(g, "" + i, this.fH, 2, 380, yy + 4);
/*     */       }
/* 518 */     g.setColor(this.this$0.colorAcceleration);
/* 519 */     alignText(g, "a", this.fH, 1, 363, 185);
/* 520 */     alignText(g, this.this$0.text14, this.fH, 1, 363, 195);
/* 521 */     alignText(g, this.this$0.valToString("a = ", this.this$0.a, 2, " " + this.this$0.meterPerSecond2), this.fH, 1, 450, 380);
/* 522 */     double xx = 390.0D + this.this$0.t * 8.0D;double yy = 270.0D - this.this$0.a * 30.0D;
/* 523 */     if (xx <= 490.0D) {
/* 524 */       circle(g, xx, yy, 2.0D, this.this$0.colorAcceleration, true);
/* 525 */       g.setColor(this.this$0.colorAcceleration);
/* 526 */       line(g, 390.0D, yy, xx, yy);
/*     */     } else {
/* 528 */       line(g, 390.0D, yy, 490.0D, yy);
/*     */     }
/*     */   }
/*     */   
/*     */   public void paint(Graphics g)
/*     */   {
/* 534 */     super.paint(g);
/* 535 */     Graphics2D g2 = (Graphics2D)g;
/* 536 */     g.setFont(this.fH);
/* 537 */     setAntiAliasing(g2, true);
/* 538 */     street(g2);
/* 539 */     car(g2);
/* 540 */     lBarrier(g2, this.this$0.xLB1, this.this$0.colorLightBarrier1);
/* 541 */     lBarrier(g2, this.this$0.xLB2, this.this$0.colorLightBarrier2);
/* 542 */     clock(g2, 80, 150, this.this$0.t, Color.gray);
/* 543 */     double tt = this.this$0.t;
/* 544 */     if (this.this$0.tLB1 > 0.0D) tt = Math.min(this.this$0.t, this.this$0.tLB1);
/* 545 */     clock(g2, 250, 150, tt, this.this$0.colorLightBarrier1);
/* 546 */     tt = this.this$0.t;
/* 547 */     if (this.this$0.tLB2 > 0.0D) tt = Math.min(this.this$0.t, this.this$0.tLB2);
/* 548 */     clock(g2, 420, 150, tt, this.this$0.colorLightBarrier2);
/* 549 */     diagramTX(g2);
/* 550 */     diagramTV(g2);
/* 551 */     diagramTA(g2);
/* 552 */     g.setColor(Color.black);
/* 553 */     alignText(g2, this.this$0.valToString("x = ", this.this$0.xLB1, 3, " " + this.this$0.meter), this.fH, 1, 250, 125);
/* 554 */     alignText(g2, this.this$0.valToString("x = ", this.this$0.xLB2, 3, " " + this.this$0.meter), this.fH, 1, 420, 125);
/*     */   }
/*     */ }


/* Location:              C:\Users\User\Downloads\acceleration_en.jar!\AccelerationAP$CanvasAP.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */