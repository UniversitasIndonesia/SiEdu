/*    */ import java.awt.Color;
/*    */ import javax.swing.JButton;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class StartButton
/*    */   extends JButton
/*    */ {
/*    */   private int state;
/*    */   private ButtonIcon iconPlay;
/*    */   private ButtonIcon iconPause;
/*    */   private String[] text;
/*    */   
/*    */   public StartButton(String s0, String s1, String s2)
/*    */   {
/* 56 */     setBackground(Color.yellow);
/* 57 */     this.iconPlay = new ButtonIcon(1);
/* 58 */     this.iconPause = new ButtonIcon(2);
/* 59 */     this.text = new String[3];
/* 60 */     this.text[0] = s0;this.text[1] = s1;this.text[2] = s2;
/* 61 */     setState(0);
/* 62 */     setIconTextGap(50);
/* 63 */     setFocusPainted(false);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   public void setState(int i)
/*    */   {
/* 75 */     this.state = i;
/* 76 */     if (i == 1) setIcon(this.iconPause); else setIcon(this.iconPlay);
/* 77 */     setText(this.text[i]);
/*    */   }
/*    */   
/*    */ 
/*    */   public void setState()
/*    */   {
/* 83 */     setState(this.state == 0 ? 1 : 3 - this.state);
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public int getState()
/*    */   {
/* 91 */     return this.state;
/*    */   }
/*    */ }


/* Location:              C:\Users\User\Downloads\acceleration_en.jar!\StartButton.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */