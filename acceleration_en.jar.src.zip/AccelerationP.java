/*    */ import java.awt.Container;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AccelerationP
/*    */   extends P6
/*    */ {
/*    */   public AccelerationP()
/*    */   {
/* 14 */     this.content = new AccelerationAP();
/* 15 */     this.content.setProg(this);
/* 16 */     this.content.initAP(true, "acceleration.txt", true);
/* 17 */     setTitle(this.content.title);
/* 18 */     getContentPane().add(this.content);
/* 19 */     pack();
/*    */   }
/*    */   
/*    */ 
/*    */   public static void main(String[] args)
/*    */   {
/* 25 */     new AccelerationP();
/*    */   }
/*    */ }


/* Location:              C:\Users\User\Downloads\acceleration_en.jar!\AccelerationP.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */