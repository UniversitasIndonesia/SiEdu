/*    */ import java.awt.Container;
/*    */ import java.awt.event.WindowAdapter;
/*    */ import java.awt.event.WindowEvent;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class P6$1
/*    */   extends WindowAdapter
/*    */ {
/*    */   P6$1(P6 paramP6) {}
/*    */   
/*    */   public void windowClosing(WindowEvent e)
/*    */   {
/* 23 */     this.this$0.content.end();
/* 24 */     this.this$0.getContentPane().removeAll();
/* 25 */     this.this$0.dispose();System.exit(0);
/*    */   }
/*    */ }


/* Location:              C:\Users\User\Downloads\acceleration_en.jar!\P6$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */