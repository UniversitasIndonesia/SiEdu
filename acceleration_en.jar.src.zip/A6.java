/*    */ import javax.swing.JApplet;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class A6
/*    */   extends JApplet
/*    */ {
/*    */   protected AP6 content;
/*    */   
/*    */   public void stop()
/*    */   {
/* 19 */     this.content.end();
/*    */   }
/*    */ }


/* Location:              C:\Users\User\Downloads\acceleration_en.jar!\A6.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */