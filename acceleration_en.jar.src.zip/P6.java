/*    */ import java.awt.Container;
/*    */ import java.awt.event.WindowAdapter;
/*    */ import java.awt.event.WindowEvent;
/*    */ import javax.swing.JFrame;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class P6
/*    */   extends JFrame
/*    */ {
/*    */   protected AP6 content;
/*    */   
/*    */   public P6()
/*    */   {
/* 18 */     setResizable(false);
/* 19 */     setLocation(50, 50);
/* 20 */     setVisible(true);
/* 21 */     addWindowListener(new WindowAdapter() {
/*    */       public void windowClosing(WindowEvent e) {
/* 23 */         P6.this.content.end();
/* 24 */         P6.this.getContentPane().removeAll();
/* 25 */         P6.this.dispose();System.exit(0);
/*    */       }
/*    */     });
/*    */   }
/*    */ }


/* Location:              C:\Users\User\Downloads\acceleration_en.jar!\P6.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */