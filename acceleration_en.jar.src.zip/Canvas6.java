/*     */ import java.awt.BasicStroke;
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.RenderingHints;
/*     */ import java.awt.geom.Arc2D;
/*     */ import java.awt.geom.Arc2D.Double;
/*     */ import java.awt.geom.Ellipse2D;
/*     */ import java.awt.geom.Ellipse2D.Double;
/*     */ import java.awt.geom.GeneralPath;
/*     */ import java.awt.geom.Line2D;
/*     */ import java.awt.geom.Line2D.Double;
/*     */ import java.awt.geom.Rectangle2D;
/*     */ import java.awt.geom.Rectangle2D.Double;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.JPanel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Canvas6
/*     */   extends JPanel
/*     */ {
/*     */   protected static final double DEG = 0.017453292519943295D;
/*     */   protected static final double PI2 = 6.283185307179586D;
/*  28 */   protected static final BasicStroke THIN = new BasicStroke(1.0F);
/*     */   
/*     */ 
/*     */ 
/*  32 */   protected static final BasicStroke THICK = new BasicStroke(3.0F, 1, 1);
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  41 */   private static Line2D LINE = new Line2D.Double();
/*     */   
/*     */ 
/*     */ 
/*  45 */   private static GeneralPath POLYGON = new GeneralPath();
/*     */   
/*     */ 
/*     */ 
/*  49 */   private static Rectangle2D RECTANGLE = new Rectangle2D.Double();
/*     */   
/*     */ 
/*     */ 
/*  53 */   private static Ellipse2D ELLIPSE = new Ellipse2D.Double();
/*     */   
/*     */ 
/*     */ 
/*  57 */   private static Arc2D ARC = new Arc2D.Double();
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected AP6 frame;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected Font fH;
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   public Canvas6(AP6 p, Color c)
/*     */   {
/*  81 */     this.frame = p;
/*  82 */     setBackground(c);
/*  83 */     this.fH = new Font("Sansserif", 1, 12);
/*  84 */     setBorder(BorderFactory.createEtchedBorder());
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void setAntiAliasing(Graphics2D g, boolean aa)
/*     */   {
/*  94 */     if (aa) g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON); else {
/*  95 */       g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void alignText(Graphics2D g, String s, Font f, int typ, int x, int y)
/*     */   {
/* 108 */     FontMetrics fm = getFontMetrics(f);
/* 109 */     int w = fm.stringWidth(s);
/* 110 */     setAntiAliasing(g, false);
/* 111 */     g.drawString(s, x - typ * w / 2, y);
/* 112 */     setAntiAliasing(g, true);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   private static void setStroke(Graphics2D g, double d)
/*     */   {
/* 121 */     if (d == 1.0D) { g.setStroke(THIN);
/* 122 */     } else if (d == 3.0D) g.setStroke(THICK); else {
/* 123 */       g.setStroke(new BasicStroke((float)d));
/*     */     }
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static void line(Graphics2D g, double d, double x1, double y1, double x2, double y2)
/*     */   {
/* 138 */     setStroke(g, d);
/* 139 */     LINE.setLine(x1, y1, x2, y2);
/* 140 */     g.draw(LINE);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static void line(Graphics2D g, double x1, double y1, double x2, double y2)
/*     */   {
/* 152 */     line(g, 1.0D, x1, y1, x2, y2);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static void arrow(Graphics2D g, double d, double x1, double y1, double x2, double y2)
/*     */   {
/* 165 */     double dx = x2 - x1;double dy = y2 - y1;
/* 166 */     double length = Math.sqrt(dx * dx + dy * dy);
/* 167 */     if (length == 0.0D) return;
/* 168 */     dx /= length;dy /= length;
/* 169 */     setStroke(g, d);
/* 170 */     double s = 2.5D * d + 7.5D;
/* 171 */     double xSp = x2 - s * dx;double ySp = y2 - s * dy;
/* 172 */     if (length < 5.0D) return;
/* 173 */     double h = 0.5D * d + 3.5D;
/* 174 */     double xSp1 = xSp - h * dy;double ySp1 = ySp + h * dx;
/* 175 */     double xSp2 = xSp + h * dy;double ySp2 = ySp - h * dx;
/* 176 */     xSp = x2 - 0.6D * s * dx;ySp = y2 - 0.6D * s * dy;
/* 177 */     line(g, d, x1, y1, xSp, ySp);
/* 178 */     POLYGON.reset();
/* 179 */     POLYGON.moveTo((float)xSp1, (float)ySp1);
/* 180 */     POLYGON.lineTo((float)x2, (float)y2);
/* 181 */     POLYGON.lineTo((float)xSp2, (float)ySp2);
/* 182 */     POLYGON.lineTo((float)xSp, (float)ySp);
/* 183 */     POLYGON.lineTo((float)xSp1, (float)ySp1);
/* 184 */     g.fill(POLYGON);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static void arrow(Graphics2D g, double x1, double y1, double x2, double y2)
/*     */   {
/* 196 */     arrow(g, 1.0D, x1, y1, x2, y2);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void polygon(Graphics2D g, double d, double[] x, double[] y, Color c, boolean f)
/*     */   {
/* 209 */     setStroke(g, d);
/* 210 */     POLYGON.reset();
/* 211 */     POLYGON.moveTo((float)x[0], (float)y[0]);
/* 212 */     int dimX = x.length;int dimY = y.length;
/* 213 */     int dim = Math.min(dimX, dimY);
/* 214 */     for (int i = 1; i < dim; i++)
/* 215 */       POLYGON.lineTo((float)x[i], (float)y[i]);
/* 216 */     POLYGON.lineTo((float)x[0], (float)y[0]);
/* 217 */     g.setColor(c);
/* 218 */     if (f) { g.fill(POLYGON);g.setColor(Color.black); }
/* 219 */     g.draw(POLYGON);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void polygon(Graphics2D g, double[] x, double[] y, Color c, boolean f)
/*     */   {
/* 231 */     polygon(g, 1.0D, x, y, c, f);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void rectangle(Graphics2D g, double d, double x, double y, double w, double h, Color c, boolean f)
/*     */   {
/* 246 */     setStroke(g, d);
/* 247 */     RECTANGLE.setRect(x, y, w, h);
/* 248 */     g.setColor(c);
/* 249 */     if (f) { g.fill(RECTANGLE);g.setColor(Color.black); }
/* 250 */     g.draw(RECTANGLE);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected void rectangle(Graphics2D g, double x, double y, double w, double h, Color c, boolean f)
/*     */   {
/* 264 */     rectangle(g, 1.0D, x, y, w, h, c, f);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static void circle(Graphics2D g, double d, double x, double y, double r, Color c, boolean f)
/*     */   {
/* 278 */     setStroke(g, d);
/* 279 */     ELLIPSE.setFrame(x - r, y - r, 2.0D * r, 2.0D * r);
/* 280 */     g.setColor(c);
/* 281 */     if (f) { g.fill(ELLIPSE);g.setColor(Color.black); }
/* 282 */     g.draw(ELLIPSE);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static void circle(Graphics2D g, double x, double y, double r, Color c, boolean f)
/*     */   {
/* 295 */     circle(g, 1.0D, x, y, r, c, f);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static void circle(Graphics2D g, double x, double y, double r, Color c)
/*     */   {
/* 307 */     ELLIPSE.setFrame(x - r, y - r, 2.0D * r, 2.0D * r);
/* 308 */     g.setColor(c);
/* 309 */     g.fill(ELLIPSE);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static void arc(Graphics2D g, double d, double x, double y, double r, double w0, double dw)
/*     */   {
/* 323 */     setStroke(g, d);
/* 324 */     ARC.setFrame(x - r, y - r, 2.0D * r, 2.0D * r);
/* 325 */     ARC.setAngleStart(w0 / 0.017453292519943295D);
/* 326 */     ARC.setAngleExtent(dw / 0.017453292519943295D);
/* 327 */     g.draw(ARC);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static void arc(Graphics2D g, double x, double y, double r, double w0, double dw)
/*     */   {
/* 340 */     arc(g, 1.0D, x, y, r, w0, dw);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   protected static void angle(Graphics2D g, double x, double y, double r, double w0, double dw, Color c)
/*     */   {
/* 354 */     if (w0 < 0.0D) w0 += 6.283185307179586D;
/* 355 */     if (w0 > 6.283185307179586D) w0 -= 6.283185307179586D;
/* 356 */     if (dw < 0.0D) dw += 6.283185307179586D;
/* 357 */     if (dw > 6.283185307179586D) dw -= 6.283185307179586D;
/* 358 */     ARC.setArc(x - r, y - r, 2.0D * r, 2.0D * r, w0 / 0.017453292519943295D, dw / 0.017453292519943295D, 2);
/* 359 */     g.setColor(c);g.fill(ARC);
/* 360 */     g.setColor(Color.black);g.draw(ARC);
/*     */   }
/*     */ }


/* Location:              C:\Users\User\Downloads\acceleration_en.jar!\Canvas6.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */