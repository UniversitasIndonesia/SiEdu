/*     */ import java.awt.Color;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.Font;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Graphics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.event.MouseListener;
/*     */ import java.awt.event.MouseMotionListener;
/*     */ import javax.swing.ButtonGroup;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JRadioButton;
/*     */ import javax.swing.JTextField;
/*     */ 
/*     */ public class AccelerationAP
/*     */   extends AP6
/*     */   implements MouseListener, MouseMotionListener
/*     */ {
/*     */   String[][] text;
/*     */   final int width = 780;
/*     */   final int height = 400;
/*     */   final int width0 = 540;
/*     */   private int[] gaps;
/*     */   Font fC;
/*     */   FontMetrics fmH;
/*     */   FontMetrics fmC;
/*     */   AccelerationAP.CanvasAP cv;
/*     */   Panel6 pan;
/*     */   ResetButton bReset;
/*     */   StartButton bStart;
/*     */   JCheckBox cbSlow;
/*     */   JRadioButton rbV;
/*     */   JRadioButton rbA;
/*     */   JTextField tfX0;
/*     */   JTextField tfV0;
/*     */   JTextField tfA;
/*     */   
/*     */   public AccelerationAP()
/*     */   {
/*  13 */     this.text = new String[][] { { "de", "Bewegung mit konstanter Geschwindigkeit", "Zurück", "Start", "Pause", "Weiter", "Zeitlupe", "Anfangsposition:", "Anfangsgeschwindigkeit:", "Beschleunigung:", "Geschwindigkeitsvektor", "Beschleunigungsvektor", "(in s)", "(in m)", "(in m/s)", "(in m/s²)", "" }, { "en", "Motion with Constant Acceleration", "Reset", "Start", "Pause", "Resume", "Slow motion", "Initial position:", "Initial velocity:", "Acceleration:", "Vector of velocity", "Vector of acceleration", "(in s)", "(in m)", "(in m/s)", "(in m/s²)", "" } };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  28 */     this.width = 780;this.height = 400;this.width0 = 540;
/*     */     
/*     */ 
/*  31 */     this.gaps = new int[] { 10, 5, 10, 10, 0, 10, 0, 10, 0, 10, 0, 10, 0, 10 };
/*     */     
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*  64 */     this.xS = 50;this.yS = 60;
/*  65 */     this.PIX = 8;
/*  66 */     this.PIXT = 8;
/*  67 */     this.PIXX = 2;
/*  68 */     this.PIXV = 3;
/*  69 */     this.PIXA = 30;
/*     */   }
/*     */   
/*     */   Color bgCanvas;
/*     */   Color bgPanel;
/*     */   Color colorButton1;
/*     */   Color colorButton2;
/*     */   Color colorPosition;
/*     */   Color colorVelocity;
/*     */   
/*     */   public Dimension getPreferredSize()
/*     */   {
/*  78 */     return new Dimension(780, 400);
/*     */   }
/*     */   
/*     */   Color colorAcceleration;
/*     */   Color colorLightBarrier1;
/*     */   Color colorLightBarrier2;
/*     */   
/*     */   protected void initAttributes()
/*     */   {
/*  84 */     this.on = (this.slow = 0);this.t = 0.0D;
/*  85 */     this.x0 = 0.0D;this.v0 = 0.0D;this.a = 1.0D;
/*  86 */     this.xLB1 = 25.0D;this.xLB2 = 50.0D;this.nrLB = 0;
/*  87 */     initPolygons();
/*  88 */     this.fC = new Font("Monospaced", 1, 16);
/*  89 */     this.fmC = getFontMetrics(this.fC);
/*     */   }
/*     */   
/*     */   Color colorCar1;
/*     */   Color colorCar2;
/*     */   
/*     */   protected void initColors()
/*     */   {
/*  95 */     this.bgCanvas = getColor(Color.yellow, "bgCanvas");
/*  96 */     this.bgPanel = getColor(Color.green, "bgPanel");
/*  97 */     this.colorButton1 = getColor(Color.cyan, "colorButton1");
/*  98 */     this.colorButton2 = getColor(Color.yellow, "colorButton2");
/*  99 */     this.colorPosition = getColor(Color.red, "colorPosition");
/* 100 */     this.colorVelocity = getColor(Color.magenta, "colorVelocity");
/* 101 */     this.colorAcceleration = getColor(Color.blue, "colorAcceleration");
/* 102 */     this.colorLightBarrier1 = getColor(Color.green, "colorLightBarrier1");
/* 103 */     this.colorLightBarrier2 = getColor(Color.red, "colorLightBarrier2");
/* 104 */     this.colorCar1 = getColor(new Color(192, 192, 192), "colorCar1");
/* 105 */     this.colorCar2 = getColor(Color.cyan, "colorCar2");
/*     */   }
/*     */   
/*     */   String coauthor;
/*     */   String text01;
/*     */   
/*     */   protected void initText()
/*     */   {
/* 111 */     String[] t = searchLanguage(this.text, "en");
/* 112 */     this.language = getText(this.language, "language");
/* 113 */     this.title = getText(t[1], "title");
/* 114 */     this.text01 = getText(t[2], "text01");
/* 115 */     this.text02 = getText(t[3], "text02");
/* 116 */     this.text03 = getText(t[4], "text03");
/* 117 */     this.text04 = getText(t[5], "text04");
/* 118 */     this.text05 = getText(t[6], "text05");
/* 119 */     this.text06 = getText(t[7], "text06");
/* 120 */     this.text07 = getText(t[8], "text07");
/* 121 */     this.text08 = getText(t[9], "text08");
/* 122 */     this.text09 = getText(t[10], "text09");
/* 123 */     this.text10 = getText(t[11], "text10");
/* 124 */     this.text11 = getText(t[12], "text11");
/* 125 */     this.text12 = getText(t[13], "text12");
/* 126 */     this.text13 = getText(t[14], "text13");
/* 127 */     this.text14 = getText(t[15], "text14");
/* 128 */     this.coauthor = getText(t[16], "coauthor");
/*     */   }
/*     */   
/*     */   String text02;
/*     */   String text03;
/*     */   protected void initCanvas()
/*     */   {
/* 134 */     this.cv = new AccelerationAP.CanvasAP(this);
/* 135 */     this.cv.setBounds(0, 0, 540, 400);
/* 136 */     add(this.cv);
/*     */   }
/*     */   
/*     */   protected void initPanel()
/*     */   {
/* 142 */     this.pan = new Panel6(this, this.bgPanel, 3, this.gaps);
/* 143 */     this.pan.setBounds(540, 0, 240, 400);
/* 144 */     this.bReset = new ResetButton(this.text01);
/* 145 */     this.pan.add(this.bReset, this.colorButton1, Color.black);
/* 146 */     this.bStart = new StartButton(this.text02, this.text03, this.text04);
/* 147 */     this.pan.add(this.bStart, this.colorButton2, Color.black);
/* 148 */     this.cbSlow = new JCheckBox(this.text05);
/* 149 */     this.pan.add(this.cbSlow, this.bgPanel, Color.black);
/* 150 */     this.pan.add(this.text06);
/* 151 */     this.tfX0 = new JTextField();
/* 152 */     this.tfX0.setText(toString(this.x0, 2));
/* 153 */     this.pan.add(this.tfX0, Color.white, 0, 1, 10, 0);
/* 154 */     JLabel lbUnit = new JLabel(this.meter);
/* 155 */     this.pan.add(lbUnit, this.bgPanel, 1, 1, 5, 10);
/* 156 */     this.pan.add(this.text07);
/* 157 */     this.tfV0 = new JTextField();
/* 158 */     this.tfV0.setText(toString(this.v0, 2));
/* 159 */     this.pan.add(this.tfV0, Color.white, 0, 1, 10, 0);
/* 160 */     lbUnit = new JLabel(this.meterPerSecond);
/* 161 */     this.pan.add(lbUnit, this.bgPanel, 1, 1, 5, 10);
/* 162 */     this.pan.add(this.text08);
/* 163 */     this.tfA = new JTextField();
/* 164 */     this.tfA.setText(toString(this.a, 2));
/* 165 */     this.pan.add(this.tfA, Color.white, 0, 1, 10, 0);
/* 166 */     lbUnit = new JLabel(this.meterPerSecond2);
/* 167 */     this.pan.add(lbUnit, this.bgPanel, 1, 1, 5, 10);
/* 168 */     ButtonGroup bg = new ButtonGroup();
/* 169 */     this.rbV = new JRadioButton(this.text09, true);bg.add(this.rbV);
/* 170 */     this.pan.add(this.rbV, this.bgPanel, Color.black);
/* 171 */     this.rbA = new JRadioButton(this.text10, false);bg.add(this.rbA);
/* 172 */     this.pan.add(this.rbA, this.bgPanel, Color.black);
/* 173 */     this.pan.add(2000);
/* 174 */     this.pan.add(this.coauthor);
/* 175 */     add(this.pan);
/* 176 */     this.bReset.addActionListener(this);
/* 177 */     this.bStart.addActionListener(this);
/* 178 */     this.cbSlow.addActionListener(this);
/* 179 */     this.rbV.addActionListener(this);
/* 180 */     this.rbA.addActionListener(this);
/* 181 */     this.tfA.addActionListener(this);
/* 182 */     this.tfV0.addActionListener(this);
/* 183 */     this.tfX0.addActionListener(this);
/* 184 */     this.cv.addMouseListener(this);
/* 185 */     this.cv.addMouseMotionListener(this);
/*     */   }
/*     */   String text04;
/*     */   String text05;
/*     */   String text06;
/*     */   String text07;
/*     */   
/*     */   public void run()
/*     */   {
/* 191 */     long t0 = System.currentTimeMillis();
/* 192 */     while (this.thr == Thread.currentThread())
/*     */     {
/* 193 */       if (this.on) this.cv.repaint();
/* 194 */       try { Thread.sleep(this.on ? 50L : 100L);
/*     */       } catch (InterruptedException ie) {}
/* 196 */       long t1 = System.currentTimeMillis();
/* 197 */       if (this.on) {
/* 198 */         double dt = (t1 - t0) / 1000.0D;
/* 199 */         this.t += (this.slow ? dt / 10.0D : dt);
/*     */       }
/* 201 */       t0 = t1;
/*     */     }
/*     */   }
/*     */   
/*     */   String text08;
/*     */   String text09;
/*     */   String text10;
/*     */   String text11;
/*     */   String text12;
/*     */   String text13;
/*     */   String text14;
/*     */   
/*     */   String valToString(String beg, double v, int n, String end)
/*     */   {
/* 208 */     return beg + toString(v, n) + end;
/*     */   }
/*     */   
/*     */   double t;
/*     */   boolean on;
/*     */   boolean slow;
/*     */   
/*     */   void initPolygons()
/*     */   {
/* 215 */     this.xCar = new double[7];
/* 216 */     this.xCar[0] = 0.0D;this.xCar[1] = -1.0D;this.xCar[2] = -8.0D;this.xCar[3] = -12.0D;
/* 217 */     this.xCar[4] = -24.0D;this.xCar[5] = (this.xCar[6] = -30.0D);
/* 218 */     this.yCar = new double[7];
/* 219 */     this.yCar[0] = 58.0D;this.yCar[1] = (this.yCar[2] = 52.0D);this.yCar[3] = (this.yCar[4] = 46.0D);
/* 220 */     this.yCar[5] = 51.0D;this.yCar[6] = 58.0D;
/* 221 */     this.xWindow = new double[4];
/* 222 */     this.xWindow[0] = -11.0D;this.xWindow[1] = -14.0D;this.xWindow[2] = (this.xWindow[3] = -22.0D);
/* 223 */     this.yWindow = new double[4];
/* 224 */     this.yWindow[0] = (this.yWindow[3] = 52.0D);this.yWindow[1] = (this.yWindow[2] = 49.0D);
/*     */   }
/*     */   
/*     */   double x0;
/*     */   double x;
/*     */   double xx;
/*     */   
/*     */   void translate(double dx)
/*     */   {
/* 230 */     for (int i = 0; i < this.xCar.length; i++)
/* 231 */       this.xCar[i] += dx;
/* 232 */     for (int i = 0; i < this.xWindow.length; i++) {
/* 233 */       this.xWindow[i] += dx;
/*     */     }
/*     */   }
/*     */   
/*     */   double v0;
/*     */   double v;
/*     */   double a;
/*     */   
/*     */   double timeLB(double xLB)
/*     */   {
/* 242 */     if (this.a == 0.0D) return (xLB - this.x0) / this.v0;
/* 243 */     double diskr = this.v0 * this.v0 + 2.0D * this.a * (xLB - this.x0);
/* 244 */     if (diskr < 0.0D) return -1.0D;
/* 245 */     double wu = Math.sqrt(diskr);
/* 246 */     double t1 = (-this.v0 + wu) / this.a;double t2 = (-this.v0 - wu) / this.a;
/* 247 */     if (this.a < 0.0D) { double h = t1;t1 = t2;t2 = h; }
/* 248 */     if (t1 > 0.0D) return t1;
/* 249 */     if (t2 > 0.0D) return t2;
/* 250 */     return -1.0D;
/*     */   }
/*     */   int nrLB;
/*     */   double xLB1;
/*     */   double xLB2;
/*     */   double tLB1;
/*     */   
/*     */   void changeValues()
/*     */   {
/* 256 */     this.a = inputTF(this.tfA, -2.0D, 2.0D, 2);
/* 257 */     this.v0 = inputTF(this.tfV0, -10.0D, 10.0D, 2);
/* 258 */     this.x0 = inputTF(this.tfX0, 0.0D, 50.0D, 2);
/* 259 */     this.tLB1 = timeLB(this.xLB1);this.tLB2 = timeLB(this.xLB2);
/*     */   }
/*     */   
/*     */   double tLB2;
/*     */   final int xS = 50;
/*     */   final int yS = 60;
/*     */   final int PIX = 8;
/*     */   
/*     */   void setTF(boolean flag)
/*     */   {
/* 265 */     this.tfA.setEnabled(flag);
/* 266 */     this.tfV0.setEnabled(flag);
/* 267 */     this.tfX0.setEnabled(flag);
/*     */   }
/*     */   
/*     */   final int PIXT = 8;
/*     */   final int PIXX = 2;
/*     */   
/*     */   double getX0()
/*     */   {
/* 272 */     return this.x0;
/*     */   }
/*     */   
/*     */   final int PIXV = 3;
/*     */   final int PIXA = 30;
/*     */   double[] xCar;
/*     */   double[] yCar;
/*     */   double[] xWindow;
/*     */   double[] yWindow;
/*     */   public void actionPerformed(ActionEvent ae)
/*     */   {
/* 280 */     this.slow = this.cbSlow.isSelected();
/* 281 */     Object o = ae.getSource();
/* 282 */     if (o == this.bReset) {
/* 283 */       this.bStart.setState(0);setTF(true);
/* 284 */       this.t = 0.0D;
/*     */     }
/* 286 */     else if (o == this.bStart) {
/* 287 */       this.bStart.setState();setTF(false);
/* 288 */       changeValues();
/*     */     }
/* 290 */     else if ((o instanceof JTextField)) { changeValues(); }
/* 291 */     this.on = (this.bStart.getState() == 1);
/* 292 */     repaint();
/*     */   }
/*     */   
/*     */   public void mousePressed(MouseEvent me)
/*     */   {
/* 299 */     int x = me.getX();int y = me.getY();
/* 300 */     if ((y > 60) || (y < 40)) { this.nrLB = 0;return; }
/* 301 */     double min = (int)Math.abs(x - (50.0D + this.xLB1 * 8.0D));
/* 302 */     this.nrLB = 1;
/* 303 */     double d = Math.abs(x - (50.0D + this.xLB2 * 8.0D));
/* 304 */     if (d < min) { min = d;this.nrLB = 2; }
/* 305 */     if (min > 10.0D) {
/* 305 */       this.nrLB = 0;
/*     */     }
/*     */   }
/*     */   
/*     */   public void mouseDragged(MouseEvent me)
/*     */   {
/* 312 */     int xMin = 50;int xMax = 450;
/* 313 */     switch (this.nrLB) {
/* 314 */     case 0:  return;
/*     */     case 1: 
/* 316 */       xMax = (int)Math.round(50.0D + (this.xLB2 - 1.0D) * 8.0D); break;
/*     */     case 2: 
/* 318 */       xMin = (int)Math.round(50.0D + (this.xLB1 + 1.0D) * 8.0D);
/*     */     }
/* 320 */     this.on = false;this.t = 0.0D;setTF(true);
/* 321 */     int x = me.getX();int y = me.getY();
/* 322 */     if ((y > 60) || (y < 40)) return;
/* 323 */     if (x < xMin) x = xMin;
/* 324 */     if (x > xMax) x = xMax;
/* 325 */     double xLB = (x - 50) / 8.0D;
/* 326 */     if (this.nrLB == 1) this.xLB1 = xLB; else { this.xLB2 = xLB;
/*     */     }
/* 328 */     this.cv.repaint();
/*     */   }
/*     */   
/*     */   public void mouseClicked(MouseEvent e) {}
/*     */   
/*     */   public void mouseReleased(MouseEvent e) {}
/*     */   
/*     */   public void mouseMoved(MouseEvent e) {}
/*     */   
/*     */   public void mouseEntered(MouseEvent e) {}
/*     */   
/*     */   public void mouseExited(MouseEvent e) {}
/*     */   
/*     */   class CanvasAP
/*     */     extends Canvas6
/*     */   {
/*     */     CanvasAP(AP6 ap)
/*     */     {
/* 347 */       super(AccelerationAP.this.bgCanvas);
/* 348 */       AccelerationAP.this.fmH = getFontMetrics(this.fH);
/*     */     }
/*     */     
/*     */     void horArrow(Graphics2D g, double x0, double y0, double w)
/*     */     {
/* 354 */       arrow(g, 3.0D, x0, y0, x0 + w, y0);
/*     */     }
/*     */     
/*     */     void street(Graphics2D g)
/*     */     {
/* 360 */       g.setColor(Color.black);
/* 361 */       line(g, 1.0D, 60.0D, 538.0D, 60.0D);
/* 362 */       int xx = 500;int yy = 75;
/* 363 */       arrow(g, 40.0D, yy, xx, yy);
/* 364 */       alignText(g, "x", this.fH, 1, xx, yy + 15);
/* 365 */       alignText(g, AccelerationAP.this.text12, this.fH, 1, xx, yy + 25);
/* 366 */       int pix5 = 40;
/* 367 */       for (int i = 0; i <= 10; i++)
/*     */       {
/* 368 */         xx = 50 + i * pix5;
/* 369 */         line(g, xx, yy - 2, xx, yy + 2);
/* 370 */         alignText(g, "" + i * 5, this.fH, 1, xx, yy + 15);
/*     */       }
/*     */     }
/*     */     
/*     */     void car(Graphics2D g)
/*     */     {
/* 377 */       AccelerationAP.this.x = (AccelerationAP.this.a * AccelerationAP.this.t * AccelerationAP.this.t / 2.0D + AccelerationAP.this.v0 * AccelerationAP.this.t + AccelerationAP.this.x0);
/* 378 */       AccelerationAP.this.v = (AccelerationAP.this.a * AccelerationAP.this.t + AccelerationAP.this.v0);
/* 379 */       double xNeu = 50.0D + AccelerationAP.this.x * 8.0D;
/* 380 */       double dx = xNeu - AccelerationAP.this.xx;
/* 381 */       AccelerationAP.this.xx = xNeu;
/* 382 */       AccelerationAP.this.translate(dx);
/* 383 */       polygon(g, AccelerationAP.this.xCar, AccelerationAP.this.yCar, AccelerationAP.this.colorCar1, true);
/* 384 */       polygon(g, AccelerationAP.this.xWindow, AccelerationAP.this.yWindow, AccelerationAP.this.colorCar2, true);
/* 385 */       double yy = 57.0D;
/* 386 */       line(g, xNeu - 18.0D, yy, xNeu - 18.0D, 48.0D);
/* 387 */       circle(g, xNeu - 23.0D, yy, 3.0D, Color.black, true);
/* 388 */       circle(g, xNeu - 7.0D, yy, 3.0D, Color.black, true);
/* 389 */       circle(g, xNeu - 16.0D, 50.0D, 1.0D, Color.black, true);
/* 390 */       yy = 54.0D;
/* 391 */       if (AccelerationAP.this.rbV.isSelected())
/*     */       {
/* 392 */         g.setColor(AccelerationAP.this.colorVelocity);
/* 393 */         double vv = AccelerationAP.this.v * 3.0D;
/* 394 */         if (AccelerationAP.this.v > 0.0D) horArrow(g, xNeu, yy, vv);
/* 395 */         if (AccelerationAP.this.v < 0.0D) {
/* 395 */           horArrow(g, xNeu - 30.0D, yy, vv);
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 398 */         g.setColor(AccelerationAP.this.colorAcceleration);
/* 399 */         double vv = AccelerationAP.this.a * 30.0D;
/* 400 */         if (AccelerationAP.this.a > 0.0D) horArrow(g, xNeu, yy, vv);
/* 401 */         if (AccelerationAP.this.a < 0.0D) {
/* 401 */           horArrow(g, xNeu - 30.0D, yy, vv);
/*     */         }
/*     */       }
/*     */     }
/*     */     
/*     */     void lBarrier(Graphics2D g, double x, Color c)
/*     */     {
/* 410 */       rectangle(g, 50.0D + x * 8.0D - 2.0D, 40.0D, 5.0D, 20.0D, c, true);
/*     */     }
/*     */     
/*     */     void clock(Graphics2D g, int x, int y, double t, Color c)
/*     */     {
/* 419 */       rectangle(g, x - 60, y - 15, 120.0D, 30.0D, c, true);
/* 420 */       rectangle(g, x - 50, y - 10, 100.0D, 20.0D, Color.black, true);
/* 421 */       g.setColor(Color.red);g.setFont(AccelerationAP.this.fC);
/* 422 */       int n = (int)(t / 100.0D);t -= 100 * n;
/* 423 */       String s = AccelerationAP.this.valToString("", t, 3, " s");
/* 424 */       int w = AccelerationAP.this.fmC.stringWidth(s);
/* 425 */       setAntiAliasing(g, false);
/* 426 */       g.drawString(s, x - w / 2, y + 5);
/* 427 */       setAntiAliasing(g, true);
/* 428 */       g.setFont(this.fH);
/*     */     }
/*     */     
/*     */     void cosy(Graphics2D g, int x, int y, int yMinus, int yPlus)
/*     */     {
/* 436 */       g.setColor(Color.black);
/* 437 */       arrow(g, x - 10, y, x + 110, y);
/* 438 */       arrow(g, x, y - yMinus, x, y - yPlus);
/* 439 */       for (int i = 1; i <= 5; i++) {
/* 440 */         int xx = x + i * 2 * 8;
/* 441 */         line(g, xx, y - 3, xx, y + 3);
/* 442 */         alignText(g, "" + 2 * i, this.fH, 1, xx, y + 15);
/*     */       }
/* 444 */       alignText(g, "t", this.fH, 1, x + 105, y + 15);
/* 445 */       alignText(g, AccelerationAP.this.text11, this.fH, 1, x + 105, y + 25);
/*     */     }
/*     */     
/*     */     void diagramTX(Graphics2D g)
/*     */     {
/* 451 */       int xU = 50;int yU = 330;
/* 452 */       double pixT = 8.0D;
/* 453 */       cosy(g, 50, 330, -10, 150);
/* 454 */       for (int i = 1; i <= 6; i++) {
/* 455 */         int yy = 330 - i * 10 * 2;
/* 456 */         line(g, 47.0D, yy, 53.0D, yy);
/* 457 */         alignText(g, "" + 10 * i, this.fH, 2, 40, yy + 4);
/*     */       }
/* 459 */       g.setColor(AccelerationAP.this.colorPosition);
/* 460 */       alignText(g, "x", this.fH, 1, 30, 185);
/* 461 */       alignText(g, AccelerationAP.this.text12, this.fH, 1, 30, 195);
/* 462 */       alignText(g, AccelerationAP.this.valToString("x = ", AccelerationAP.this.x, 2, " " + AccelerationAP.this.meter), this.fH, 1, 110, 380);
/* 463 */       double xx = 50.0D + AccelerationAP.this.t * 8.0D;double yy = 330.0D - AccelerationAP.this.x * 2.0D;
/* 464 */       if ((xx <= 150.0D) && (yy <= 330.0D) && (yy >= 190.0D))
/* 465 */         circle(g, xx, yy, 2.0D, AccelerationAP.this.colorPosition, true);
/* 466 */       g.setColor(AccelerationAP.this.colorPosition);
/* 467 */       int x0 = 50;int x1 = x0 + 1;
/* 468 */       double y0 = 330.0D - AccelerationAP.this.getX0() * 2.0D;
/* 469 */       for (; (x1 <= xx) && (x1 <= 150); 
/*     */           
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 475 */           x1++)
/*     */       {
/* 470 */         double tt = (x1 - 50) / pixT;
/* 471 */         AccelerationAP.this.x = (AccelerationAP.this.a * tt * tt / 2.0D + AccelerationAP.this.v0 * tt + AccelerationAP.this.getX0());
/* 472 */         double y1 = 330.0D - AccelerationAP.this.x * 2.0D;
/* 473 */         if ((y0 <= 360.0D) && (y0 >= 190.0D) && (y1 <= 360.0D) && (y1 >= 190.0D))
/* 474 */           line(g, x0, y0, x1, y1);
/* 475 */         x0 = x1;y0 = y1;
/*     */       }
/*     */     }
/*     */     
/*     */     void diagramTV(Graphics2D g)
/*     */     {
/* 482 */       int xU = 220;int yU = 270;
/* 483 */       cosy(g, 220, 270, -70, 90);
/* 484 */       for (int i = -4; i <= 4; i++)
/* 485 */         if (i != 0) {
/* 486 */           int yy = 270 - i * 5 * 3;
/* 487 */           line(g, 217.0D, yy, 223.0D, yy);
/* 488 */           alignText(g, "" + 5 * i, this.fH, 2, 210, yy + 4);
/*     */         }
/* 490 */       g.setColor(AccelerationAP.this.colorVelocity);
/* 491 */       alignText(g, "v", this.fH, 1, 195, 185);
/* 492 */       alignText(g, AccelerationAP.this.text13, this.fH, 1, 195, 195);
/* 493 */       alignText(g, AccelerationAP.this.valToString("v = ", AccelerationAP.this.v, 2, " " + AccelerationAP.this.meterPerSecond), this.fH, 1, 280, 380);
/* 494 */       double xx = 220.0D + AccelerationAP.this.t * 8.0D;double yy = 270.0D - AccelerationAP.this.v * 3.0D;
/* 495 */       double yy0 = 270.0D - AccelerationAP.this.v0 * 3.0D;
/* 496 */       if (xx <= 320.0D)
/*     */       {
/* 497 */         circle(g, xx, yy, 2.0D, AccelerationAP.this.colorVelocity, true);
/* 498 */         g.setColor(AccelerationAP.this.colorVelocity);
/* 499 */         line(g, 220.0D, yy0, xx, yy);
/*     */       }
/*     */       else
/*     */       {
/* 502 */         yy = 270.0D - (AccelerationAP.this.a * 100.0D / 8.0D + AccelerationAP.this.v0) * 3.0D;
/* 503 */         line(g, 220.0D, yy0, 320.0D, yy);
/*     */       }
/*     */     }
/*     */     
/*     */     void diagramTA(Graphics2D g)
/*     */     {
/* 510 */       int xU = 390;int yU = 270;
/* 511 */       cosy(g, 390, 270, -70, 90);
/* 512 */       for (int i = -2; i <= 2; i++)
/* 513 */         if (i != 0) {
/* 514 */           int yy = 270 - i * 30;
/* 515 */           line(g, 387.0D, yy, 393.0D, yy);
/* 516 */           alignText(g, "" + i, this.fH, 2, 380, yy + 4);
/*     */         }
/* 518 */       g.setColor(AccelerationAP.this.colorAcceleration);
/* 519 */       alignText(g, "a", this.fH, 1, 363, 185);
/* 520 */       alignText(g, AccelerationAP.this.text14, this.fH, 1, 363, 195);
/* 521 */       alignText(g, AccelerationAP.this.valToString("a = ", AccelerationAP.this.a, 2, " " + AccelerationAP.this.meterPerSecond2), this.fH, 1, 450, 380);
/* 522 */       double xx = 390.0D + AccelerationAP.this.t * 8.0D;double yy = 270.0D - AccelerationAP.this.a * 30.0D;
/* 523 */       if (xx <= 490.0D)
/*     */       {
/* 524 */         circle(g, xx, yy, 2.0D, AccelerationAP.this.colorAcceleration, true);
/* 525 */         g.setColor(AccelerationAP.this.colorAcceleration);
/* 526 */         line(g, 390.0D, yy, xx, yy);
/*     */       }
/*     */       else
/*     */       {
/* 528 */         line(g, 390.0D, yy, 490.0D, yy);
/*     */       }
/*     */     }
/*     */     
/*     */     public void paint(Graphics g)
/*     */     {
/* 534 */       super.paint(g);
/* 535 */       Graphics2D g2 = (Graphics2D)g;
/* 536 */       g.setFont(this.fH);
/* 537 */       setAntiAliasing(g2, true);
/* 538 */       street(g2);
/* 539 */       car(g2);
/* 540 */       lBarrier(g2, AccelerationAP.this.xLB1, AccelerationAP.this.colorLightBarrier1);
/* 541 */       lBarrier(g2, AccelerationAP.this.xLB2, AccelerationAP.this.colorLightBarrier2);
/* 542 */       clock(g2, 80, 150, AccelerationAP.this.t, Color.gray);
/* 543 */       double tt = AccelerationAP.this.t;
/* 544 */       if (AccelerationAP.this.tLB1 > 0.0D) tt = Math.min(AccelerationAP.this.t, AccelerationAP.this.tLB1);
/* 545 */       clock(g2, 250, 150, tt, AccelerationAP.this.colorLightBarrier1);
/* 546 */       tt = AccelerationAP.this.t;
/* 547 */       if (AccelerationAP.this.tLB2 > 0.0D) tt = Math.min(AccelerationAP.this.t, AccelerationAP.this.tLB2);
/* 548 */       clock(g2, 420, 150, tt, AccelerationAP.this.colorLightBarrier2);
/* 549 */       diagramTX(g2);
/* 550 */       diagramTV(g2);
/* 551 */       diagramTA(g2);
/* 552 */       g.setColor(Color.black);
/* 553 */       alignText(g2, AccelerationAP.this.valToString("x = ", AccelerationAP.this.xLB1, 3, " " + AccelerationAP.this.meter), this.fH, 1, 250, 125);
/* 554 */       alignText(g2, AccelerationAP.this.valToString("x = ", AccelerationAP.this.xLB2, 3, " " + AccelerationAP.this.meter), this.fH, 1, 420, 125);
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\User\Downloads\acceleration_en.jar!\AccelerationAP.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */