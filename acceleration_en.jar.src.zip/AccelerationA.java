/*    */ import java.awt.Container;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AccelerationA
/*    */   extends A6
/*    */ {
/*    */   public void start()
/*    */   {
/* 10 */     this.content = new AccelerationAP();
/* 11 */     this.content.setApplet(this);
/* 12 */     this.content.initAP(false, null, true);
/* 13 */     getContentPane().add(this.content);
/*    */   }
/*    */ }


/* Location:              C:\Users\User\Downloads\acceleration_en.jar!\AccelerationA.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */